@component('mail::message')
# Pemberitahuan

Ini adalah contoh email notifikasi.

Thanks,<br>
{{ config('app.name') }}
@endcomponent