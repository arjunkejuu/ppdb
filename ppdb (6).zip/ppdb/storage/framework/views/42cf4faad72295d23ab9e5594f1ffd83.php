

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="p-5 bg-white rounded">
        <?php echo csrf_field(); ?>
        <form action="<?php echo e(route('status')); ?>" method="GET">
            <h3>Cari berdasarkan nama</h3>
            <div class="input-group mb-5">
                <input class="form-control" type="search" placeholder="Masukkan nama ..." name="query" value="<?php echo e(request('query')); ?>" id="">
                <button class="btn btn-primary" type="submit">Search</button>
            </div>
        </form>
        
        <?php if(isset($results)): ?>
            <h2>Status Pendaftaran PDB</h2>
            <?php if($results->isEmpty()): ?>
                <p>Nama siswa tidak ada yang cocok</p>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-striped text-center">
                        <thead>
                            <tr>
                                <th scope="col" class="col-1">#</th>
                                <th scope="col" class="col-4">Nama PDB</th>
                                <th scope="col" class="col-4">Orang Tua</th>
                                <th scope="col" class="col-3">Status Pendaftaran</th>
                            </tr>
                        </thead>
                        <tbody class="table-group-divider align-middle">
                            <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($index + 1); ?></th>
                                    <td><?php echo e($result->nama_pdb); ?></td>
                                    <td><?php echo e($result->nama_ibu); ?></td>
                                    <td>
                                        <button class="btn btn-warning btn-sm" disabled="disabled"><?php echo e($result->status_pendaftaran); ?></button>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <div class="justify-content-center">
                        <?php echo e($results->appends(request()->input())->links('pagination::bootstrap-5')); ?>

                    </div>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Kuliah\1. TUGAS AKHIR\TA\ppdb\resources\views/pdb/status.blade.php ENDPATH**/ ?>