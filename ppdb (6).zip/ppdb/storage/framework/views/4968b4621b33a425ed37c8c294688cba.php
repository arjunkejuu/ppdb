<?php echo e($slot); ?>

<?php /**PATH E:\Kuliah\1. TUGAS AKHIR\TA\ppdb\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>