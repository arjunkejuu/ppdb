

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row p-5 bg-white rounded">
            <div class="col">Daftar Formulir Murid Baru</div>
            <table id="example" class="display table table-striped" style="width:100%">
                <thead>
                    <tr>
                        <th>Nama PDB</th>
                        <th>Orang Tua</th>
                        <th>Status Pendaftaran</th>
                        <th>Tanggal Daftar</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody class="table-group-divider">
                    <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($result->nama_pdb); ?></td>
                            <td><?php echo e($result->nama_ibu); ?></td>
                            <td>
                                
                                <?php if($result->kartu_keluarga): ?>
                                    <img src="<?php echo e(asset('storage/'.$result->kartu_keluarga)); ?>" alt="" width="100px">
                                    <p>Path: <?php echo e(asset('storage/'.$result->kartu_keluarga)); ?></p>
                                <?php else: ?>
                                    No Image
                                    <p>Path: <?php echo e(asset('storage/'.$result->kartu_keluarga)); ?></p>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e(\Carbon\Carbon::parse($result->tanggal_lahir)->format('d/m/Y')); ?></td>
                            <td>Ubah</td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    
    
    <div class="modal fade" id="detailModal" tabindex="-1" role="dialog" aria-labelledby="detailModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="detailModalLabel">Employee Details</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <p><strong>Nama:</strong> <span id="detailName"></span></p>
                    <p><strong>Tanggal lahir:</strong> <span id="detailPosition"></span></p>
                    <p><strong>Tempat lahir:</strong> <span id="detailOffice"></span></p>
                    <p><strong>Agama:</strong> <span id="detailAge"></span></p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="https://code.jquery.com/jquery-3.7.1.js"></script>
<script src="https://cdn.datatables.net/2.1.3/js/dataTables.js"></script>
<script src="https://cdn.datatables.net/2.1.3/js/dataTables.bootstrap5.js"></script>
<script src="https://cdn.datatables.net/plug-ins/2.1.3/sorting/date-uk.js"></script>
<script>
    $(document).ready(function(){
        $('#example').DataTable({
            "order": [['created_at', 'desc']],
            "columnDefs": [
                {"orderable": false, "targets": 4},
                {type: "date-uk", "targets": 3}
            ]
        });
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Kuliah\1. TUGAS AKHIR\TA\ppdb\resources\views\admin\dashboard.blade.php ENDPATH**/ ?>